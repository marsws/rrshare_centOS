1. 配置参数 conf/rrshare.json 主要修改web端口号
2. 运行程序
   运行 ./rrshareweb 
   远程ssh运行可以考虑使用tmux/screen等工具运行， 也可以做成服务
3. 使用http://ip:port （默认port为3001）打开后台  解锁密码默认为123456，可在设置里面修改